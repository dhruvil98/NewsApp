from scripts.json_handler import *




"""
def search(keywords):

	article_data = load(article)

	matched = []

	for i in article_data.keys():

		matched.append([len(i["keywords"].intersect(keywords)), i["keywords"], i])

	return list(sorted(matched))
"""


# News-App
A web app to view latest news with features like google translate and text to speech.



